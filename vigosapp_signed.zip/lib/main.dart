import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(VigosApp(prefs: prefs));
}

class VigosApp extends StatelessWidget {
  final SharedPreferences prefs;
  const VigosApp({Key? key, required this.prefs}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VigosApp - Control Tarjetas',
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.pink)),
      home: HomePage(prefs: prefs),
    );
  }
}

class CreditCardModel {
  String name;
  double limit;
  double balance;
  String colorLabel;

  CreditCardModel({required this.name, required this.limit, this.balance = 0, required this.colorLabel});

  double get usagePercent => limit == 0 ? 0 : (balance / limit) * 100;

  Map<String, dynamic> toJson() => {'name': name, 'limit': limit, 'balance': balance, 'colorLabel': colorLabel};

  static CreditCardModel fromJson(Map<String, dynamic> j) => CreditCardModel(
        name: j['name'],
        limit: (j['limit'] as num).toDouble(),
        balance: (j['balance'] as num).toDouble(),
        colorLabel: j['colorLabel'],
      );
}

class HomePage extends StatefulWidget {
  final SharedPreferences prefs;
  const HomePage({Key? key, required this.prefs}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<CreditCardModel> cards = [];
  final storageKey = 'vigoscards_v1';

  @override
  void initState() {
    super.initState();
    _loadCards();
  }

  void _loadCards() {
    final raw = widget.prefs.getString(storageKey);
    if (raw != null) {
      final list = jsonDecode(raw) as List<dynamic>;
      cards = list.map((e) => CreditCardModel.fromJson(e)).toList();
    } else {
      cards = [
        CreditCardModel(name: 'Visa Cibao', limit: 40000, balance: 0, colorLabel: 'Rojo'),
        CreditCardModel(name: 'Visa Banreservas', limit: 40000, balance: 0, colorLabel: 'Azul claro'),
        CreditCardModel(name: 'Mastercard Reservas', limit: 60000, balance: 0, colorLabel: 'Azul claro'),
      ];
      _saveCards();
    }
    setState(() {});
  }

  Future<void> _saveCards() async {
    final raw = jsonEncode(cards.map((c) => c.toJson()).toList());
    await widget.prefs.setString(storageKey, raw);
  }

  Color _colorForCard(CreditCardModel c) {
    final p = c.usagePercent;
    if (p >= 90) return Colors.red.shade700;
    if (p >= 70) return Colors.orange.shade700;
    if (p >= 50) return Colors.yellow.shade800;
    return Colors.green.shade600;
  }

  Future<void> _addExpense(int index) async {
    final card = cards[index];
    final ctrl = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Agregar consumo a ${card.name}'),
        content: TextField(controller: ctrl, keyboardType: TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(hintText: 'Monto (ej. 1200.50)')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancelar')),
          ElevatedButton(onPressed: () { final v = double.tryParse(ctrl.text.replaceAll(',', '.')) ?? 0; setState(() { card.balance += v; }); _saveCards(); Navigator.pop(context); }, child: Text('Agregar'))
        ],
      ),
    );
  }

  Future<void> _exportCsv() async {
    final header = 'Tarjeta,Límite,Consumo,Porcentaje';
    final rows = cards.map((c) => '${c.name},${c.limit},${c.balance},${c.usagePercent.toStringAsFixed(2)}%').join('\\n');
    final csv = '$header\\n$rows';
    try {
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/tarjetas_export_${DateTime.now().millisecondsSinceEpoch}.csv');
      await file.writeAsString(csv);
      if (kIsWeb) {
        await showDialog<void>(context: context, builder: (_) => AlertDialog(title: Text('CSV'), content: SingleChildScrollView(child: Text(csv)), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('Cerrar'))]));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Exportado: ${file.path}')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error exportando: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Image.asset('assets/logo.png', width: 35, height: 35),
          SizedBox(width: 8),
          Text('VigosApp'),
        ]),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView.builder(
          itemCount: cards.length,
          itemBuilder: (context, i) {
            final c = cards[i];
            return Card(
              elevation: 3,
              child: ListTile(
                leading: CircleAvatar(backgroundColor: _colorForCard(c), child: Text(c.name.substring(0,1))),
                title: Text(c.name),
                subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Límite: ${c.limit.toStringAsFixed(0)}  • Consumo: ${c.balance.toStringAsFixed(2)}'),
                  SizedBox(height: 6),
                  LinearProgressIndicator(value: (c.usagePercent/100).clamp(0.0,1.0)),
                  SizedBox(height: 4),
                  Text('${c.usagePercent.toStringAsFixed(2)}% usado', style: TextStyle(fontSize: 12)),
                ]),
                isThreeLine: true,
                trailing: IconButton(icon: Icon(Icons.add), onPressed: () => _addExpense(i)),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _exportCsv,
        child: Icon(Icons.download),
      ),
    );
  }
}