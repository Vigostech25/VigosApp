VigosApp - Proyecto Flutter listo para compilar (Android APK)

Contenido:
- lib/main.dart  -> Código principal de la app (VigosApp)
- assets/logo.png -> Tu logo (incluido)
- pubspec.yaml -> Dependencias y assets
- .github/workflows/build-apk.yml -> GitHub Actions workflow para compilar APK automáticamente y subir el .apk como artifact

INSTRUCCIONES (rápidas):
1) Sube este proyecto a un repositorio nuevo en GitHub (archivo .zip lo contiene).
2) Ve a la pestaña 'Actions' del repositorio y permite ejecutar workflows.
3) El workflow 'build-apk.yml' generará el APK automáticamente; cuando termine, baja el artifact 'vigosapp-apk'.

Si quieres, puedo:
- Ajustar el nombre del paquete (applicationId) antes de compilar (actual: com.vigostech.vigosapp).
- Incluir keystore si quieres que el APK salga ya firmado (tendrás que enviarme el keystore o sus claves).

Automated signing (GitHub Actions)
---------------------------------
This repository includes a GitHub Actions workflow that will:

1. Generate a keystore on the runner using `keytool` with the VigosTech SRL metadata you provided.
2. Create `android/key.properties` containing the keystore passwords.
3. Build a release APK signed with that keystore.
4. Upload the signed APK as an artifact called `vigosapp-release.apk`.

**Important:** The workflow embeds the keystore password and keystore details directly in the workflow file so it can run without additional manual steps. If you prefer higher security, update the workflow to use GitHub Secrets instead.

To get your signed APK with zero local work:
1. Create a **new GitHub repository**.
2. Upload the contents of this ZIP to that repository and push to the `main` branch.
3. Go to the repository's Actions tab, allow Actions to run.
4. Trigger the workflow by pushing to `main` or use "Run workflow" from the Actions UI.
5. When the workflow completes, download the artifact `vigosapp-release.apk`.

